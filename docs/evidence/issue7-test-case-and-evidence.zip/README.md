# Issue #7 自动回归证据

## 覆盖链路

E3D TTY 自动登录并打开 `AvevaMarineSample` → 执行 CAP 位移宏并 `SAVEWORK` → 仅消费 dbnum 7999 增量 → 删除后的 `room_relate` 精确恢复为 `24381_35844 -> 24383_66460 (R512)` → 执行恢复宏并再次验证。

## 结果

- Apply：sesno `47 -> 48`，POS Z `5821.6699 -> 5921.6699`，测试 `1 passed`。
- Restore：sesno `48 -> 49`，POS Z `5921.6699 -> 5821.6699`，测试 `1 passed`。
- 合成回归：`1 passed`。
- TTY 路径单测：`7 passed`（包含 Windows verbatim 路径归一化）。

## 复现

```powershell
pwsh -File scripts/Run-Issue7E2E.ps1
```

完整输出见 `issue7-direct-apply.log`、`issue7-direct-restore.log`、`synthetic-regression.log` 和两个 driver 目录。
